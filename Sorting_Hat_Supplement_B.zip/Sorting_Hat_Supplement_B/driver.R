library(rmarkdown)

setwd("~/Research/sorting_hat/Sorting_Hat_Supplement_B/")

render("simulated_data_even.Rmd")
render("simulated_data_uneven.Rmd")
render("questionnaire_data.Rmd")
render("Figures.R") # Run last, depends on previous
