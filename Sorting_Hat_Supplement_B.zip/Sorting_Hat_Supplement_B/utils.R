tidy_array <- function(a){
  d <- dim(a)
  l <- list()
  for (i in 1:length(d)){
    l[[paste0('dim_',i)]] <- 1:d[i]
  }
  tidy <- expand.grid(l)
  tidy[["var"]] <- a[as.matrix(tidy)]
  tidy[["parameter"]] <- lazyeval::expr_text(a)
  
  return(tidy)
}