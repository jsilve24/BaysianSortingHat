library(tidyverse)
library(xtable)

setwd("~/Research/sorting_hat/Sorting_Hat_Supplement_B/")


# Create Decision Theory Table  -------------------------------------------


de <- read_csv("sim_results_even/decision_theory_results.csv")
du <- read_csv("sim_results_uneven/decision_theory_results.csv")

d <- list("Even"=de, "Uneven"=du) %>% 
  map(select, names, ol, vi, true.clust)
d$Uneven$ol.pi.Uneven <- du$ol.pi
  
d <- full_join(d$Even, d$Uneven, by="names", suffix=c(".Even", ".Uneven")) %>% 
  select(names, true.clust.Even, ol.Even, vi.Even, true.clust.Uneven, ol.Uneven, ol.pi.Uneven, vi.Uneven) %>% 
  mutate_if(is.character, substr, start=2,stop=2) %>% 
  mutate_if(is.character, as.integer)

tmp <- d %>% xtable
print(tmp, type="latex", file="combined_decision_results.tex")



# Calculate accuracy ------------------------------------------------------

accuracy <- function(a,b){
  if (length(a) != length(b)) stop("lengths must be equal")
  sum(a==b)/length(a)
}

accuracy(d$true.clust.Even, d$ol.Even)
accuracy(d$true.clust.Even, d$vi.Even)
accuracy(d$true.clust.Uneven, d$ol.Uneven)
accuracy(d$true.clust.Uneven, d$ol.pi.Uneven)
accuracy(d$true.clust.Uneven, d$vi.Uneven)


