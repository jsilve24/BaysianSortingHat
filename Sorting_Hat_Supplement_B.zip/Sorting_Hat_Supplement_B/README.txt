Title: Bayesian Sorting Hat
Author: Justin Silverman 
Modified: 2017-10-13

# Instructions to Reproduce Results
There are three main Rmarkdown documents that need to be run to reproduce the results in our associated manuscript. 
- simulated_data_even.Rmd
- simulated_data_uneven.Rmd
- questionnaire_data.Rmd

In adddition, these scripts output some results that are then combined into figures in our manuscript by the script Figures.R, therefore this script should be run last. 
